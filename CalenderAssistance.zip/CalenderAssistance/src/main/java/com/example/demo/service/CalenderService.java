package com.example.demo.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
import com.example.demo.model.Meeting;
import com.example.demo.repository.EmployeeRepository;

@Service
public class CalenderService {

	@Autowired
	private EmployeeRepository employeeRepository;

    // create employee
    public void createEmployee(Employee emp){
        employeeRepository.employeeMap.put(emp.getEmpId(),emp);
    }

    // book meeting
    public void bookMeeting(Employee employee1, Employee employee2, LocalDateTime start , LocalDateTime end) {
        if (checkTiming(employee1,start,end)){
            addMeeting(employee1,start,end);
            addMeeting(employee2,start,end);

            System.out.println("Successfully booked a meeting !!!!");
        }else
            System.out.println("Can't book the meeting ");

    }

    private void addMeeting(Employee employee1, LocalDateTime start, LocalDateTime end) {
        Meeting meeting = new Meeting();
        meeting.setStartTime(start);
        meeting.setEndTime(end);

        employee1.getMeetings().add(meeting);
    }


    boolean checkTiming(Employee employee1, LocalDateTime start, LocalDateTime end){
        List<Meeting> meetings = employee1.getMeetings();

        if (meetings.size() == 0)
            return true;

        for (Meeting meeting: meetings){
            if (meeting.getStartTime().isAfter(end) || meeting.getEndTime().isBefore(start))
                return true;
        }
        return false;
    }

    public void printCalendar(Employee emp) {
        for (Meeting meeting: emp.getMeetings()){
            System.out.println("..............Meeting Details............");
            System.out.println("Meeting Starts: " + meeting.getStartTime() + " Meeting Ends: " + meeting.getEndTime());
        }
    }
    
	public List<Employee> getEmployees() {
		
		List<Employee> empList = new ArrayList<>();
		for(String empId : employeeRepository.employeeMap.keySet()) {
			
			empList.add(employeeRepository.employeeMap.get(empId));
		}
		
		return empList;
	}
	
    public List<String> findConflicts(LocalDateTime start, LocalDateTime end) {

    	List<String> empName = new ArrayList<>();
        int t=0;
        for (String empId : EmployeeRepository.employeeMap.keySet()){
            Employee employee = EmployeeRepository.employeeMap.get(empId);
            if (!checkTiming( employee,start,end)){
                empName.add(employee.getName());
                t++;
            }
        }
        if (t==0)
            empName.add("No Conflicts !!!!");
        
		return empName;
    }
}

