package com.example.demo.model;

public class RequestObj {

		private String empId1;
		private String empId2;
		private String startDate;
		private String endDate;
		
		
		public String getEmpId1() {
			return empId1;
		}
		public String getEmpId2() {
			return empId2;
		}
		public String getStartDate() {
			return startDate;
		}
		public String getEndDate() {
			return endDate;
		}
		public void setEmpId1(String empId1) {
			this.empId1 = empId1;
		}
		public void setEmpId2(String empId2) {
			this.empId2 = empId2;
		}
		public void setStartDate(String startDate) {
			this.startDate = startDate;
		}
		public void setEndDate(String endDate) {
			this.endDate = endDate;
		}

}
