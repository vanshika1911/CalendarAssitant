package com.example.demo.repository;

import java.util.HashMap;

import org.springframework.context.annotation.Configuration;

import com.example.demo.model.Employee;

@Configuration
public class EmployeeRepository {

    public static HashMap<String, Employee> employeeMap =new HashMap<>();


}
