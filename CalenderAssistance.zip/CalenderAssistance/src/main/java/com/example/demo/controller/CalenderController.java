package com.example.demo.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.model.RequestObj;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.service.CalenderService;

@RestController
@RequestMapping("/api")
public class CalenderController {

	
	@Autowired
	private CalenderService calenderService;
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
	
	@PostMapping("/createEmployee")
	public void createEmployee(@RequestBody Employee e) {
		
		if(e != null) {
			e.setEmpId(UUID.randomUUID().toString());
			calenderService.createEmployee(e);
		}	
	}
	
	@GetMapping("/getEmployees")
	public List<Employee> getEmployees() {
		
		return calenderService.getEmployees();
	}
	
	@PostMapping("/bookMeeting")
	public void bookMeeting(@RequestBody RequestObj requestObj) {
			          
		Employee e1;
		Employee e2;
		
		if(requestObj != null && employeeRepository.employeeMap.get(requestObj.getEmpId1()) != null
				          && employeeRepository.employeeMap.get(requestObj.getEmpId2()) != null) {
			
			e1 = employeeRepository.employeeMap.get(requestObj.getEmpId1());
			e2 = employeeRepository.employeeMap.get(requestObj.getEmpId2());
			
			LocalDateTime startTime = LocalDateTime.parse(requestObj.getStartDate(), formatter);
			LocalDateTime endTime = LocalDateTime.parse(requestObj.getEndDate(), formatter);
			
			calenderService.bookMeeting(e1, e2, startTime, endTime);
		}
	}
	
	@GetMapping("/findConflicts")
	public List<String> findConflict(@RequestBody RequestObj requestObj){
		
		LocalDateTime startTime = LocalDateTime.parse(requestObj.getStartDate(), formatter);
		LocalDateTime endTime = LocalDateTime.parse(requestObj.getEndDate(), formatter);
		
		return calenderService.findConflicts(startTime, endTime);
		
	}
	
	
	
	
	
	

}
