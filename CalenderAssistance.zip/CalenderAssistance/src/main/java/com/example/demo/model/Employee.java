package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

public class Employee {

	private String name;
	private String empId;
	private Calendar calendar;
	private List<Meeting> meetings;

	public Employee(String name,String empId){
		this.name = name;
		this.empId = empId;
		meetings = new ArrayList<>();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public Calendar getCalendar() {
		return calendar;
	}

	public void setCalendar(Calendar calendar) {
		this.calendar = calendar;
	}

	public List<Meeting> getMeetings() {
		return meetings;
	}

	public void setMeetings(List<Meeting> meetings) {
		this.meetings = meetings;
	}

}
