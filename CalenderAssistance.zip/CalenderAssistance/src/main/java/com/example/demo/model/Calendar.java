package com.example.demo.model;

import java.util.Date;
import java.util.List;

public class Calendar {

	    private String calendarId;
	    private Date date;
	    List<Meeting> meetingList;

	    public String getCalendarId() {
	        return calendarId;
	    }

	    public void setCalendarId(String calendarId) {
	        this.calendarId = calendarId;
	    }

	    public Date getDate() {
	        return date;
	    }

	    public void setDate(Date date) {
	        this.date = date;
	    }
	}

